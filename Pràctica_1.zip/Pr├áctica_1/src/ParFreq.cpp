#include "ParFreq.hpp"
using namespace std;

// IMPLEMENTACIÓ DE LA CLASSE ParFreq
// (implementació de tots els mètodes especificats en el fitxer ParFreq.hpp)

// ...

// ...